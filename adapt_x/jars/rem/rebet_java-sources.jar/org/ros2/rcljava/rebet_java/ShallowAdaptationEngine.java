package org.ros2.rcljava.rebet_java;

import org.eclipse.emf.ecore.resource.ResourceSet;

public class ShallowAdaptationEngine {
  public ShallowAdaptationEngine() {
    
  }

 
}
